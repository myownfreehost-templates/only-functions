<?php
$id = md5(rand(6000,PHP_INT_MAX));
?>
<?
include('geturl.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Sign Up</title>
    <meta charset="utf-8">
    <meta name="keywords" content="free, premium, hosting, domain, subdomain, apache, ftp, web, php, HTML, CSS, JavaScript, jQuery, json, ajax, site">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"> 
</head>
<body>
<form method=post action="http://order.<?echo $yourdomain;?>/register2.php">
<br>&nbsp;<input placeholder="Subdomain" type=text name=username value="" pattern="[a-z0-9]{4,16}" maxlength="16" oninvalid="this.setCustomValidity('Enter subdomain')" oninput="setCustomValidity('')" required>
    .<?echo $yourdomain;?>&nbsp;<br>
&nbsp;<input placeholder="Password" type=password id="password" name=password pattern=".{6,16}" maxlength="16" oninvalid="this.setCustomValidity('Enter password')" oninput="setCustomValidity('')" required>
<br>&nbsp;<input placeholder="Email" type=text name=email pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" value="" oninvalid="this.setCustomValidity('Enter e-mail address')" oninput="setCustomValidity('')" required></span>&nbsp;<br>
<input type=hidden name=id value="<?PHP echo $id; ?>">
&nbsp;<img src="http://order.<? echo $yourdomain;?>/image.php?id=<?PHP echo $id; ?>">&nbsp;<br>
 &nbsp;<input placeholder="Security Code" type=text pattern=".{5,5}" name=number oninvalid="this.setCustomValidity('Enter security code')" oninput="setCustomValidity('')" required>
&nbsp;<br>
&nbsp;<button type="submit">Sign Up</button>&nbsp;<br>
</form>
</body>
</html>

