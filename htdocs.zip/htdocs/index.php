<?
include('geturl.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>uk.ke</title>
    <meta charset="utf-8">
    <meta name="keywords" content="free, premium, hosting, domain, subdomain, apache, ftp, web, php, HTML, CSS, JavaScript, jQuery, json, ajax, site">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"> 
</head>
<body>
<h2>uk.ke</h2>Free Web Hosting&nbsp;and&nbsp;Free Subdomain&nbsp;<br>
&nbsp;<a href="http://<?echo $yourdomain;?>/login.php">Sign In</a>
&nbsp;|&nbsp;<a href="http://<?echo $yourdomain;?>/signup.php">Sign Up</a>
</form>
</body>
</html>
