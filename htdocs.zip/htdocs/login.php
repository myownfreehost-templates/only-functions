<?
include('geturl.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Sign In</title>
    <meta charset="utf-8">
    <meta name="keywords" content="free, premium, hosting, domain, subdomain, apache, ftp, web, php, HTML, CSS, JavaScript, jQuery, json, ajax, site">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"> 
</head>
<body>
&nbsp;<br><form action="http://cpanel.<?echo $yourdomain;?>/login.php" method="post" name="login">
&nbsp;<input placeholder="Username" name="uname" type="password" alt="username" oninvalid="this.setCustomValidity('Enter username')" oninput="setCustomValidity('')" required><br>
&nbsp;<input placeholder="Password" type="password" name="passwd" alt="password" oninvalid="this.setCustomValidity('Enter password')" oninput="setCustomValidity('')" required><br>
&nbsp;<input type="submit" name="Submit" value="Sign In"/>
&nbsp;<br>&nbsp;<a href="http://cpanel.<?echo $yourdomain;?>/lostpassword.php"><small>Forgot password?<small></a>
</form>
</body>
</html>

